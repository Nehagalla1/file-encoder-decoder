//Sai Varsha Devineni

import java.util.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.io.*;

public class Decoder {

	public static void main(String[] args) throws Exception {
		ArrayList<String> al = new ArrayList<String>();
		ArrayList<Integer> arrl = new ArrayList<Integer>();
		double maxSize = Math.pow(2, Integer.parseInt(args[1]));
		//Getting the ASCII code
		for (int i = 0; i <= 255; i++) {
			al.add(String.valueOf((char) i));

		}
		try{
			//Converts the binary format to decimal format
		BufferedReader fis=new BufferedReader(new InputStreamReader(new FileInputStream(args[0]), "utf-16be"));
	
			while (true) {
			int s = fis.read();
			if(s==-1){
				break;
			}
			System.out.println(s);
			arrl.add(s);
			
		}
		fis.close();
		}
		catch(Exception e){

			System.out.println("Unable to open the file" + e.getStackTrace().toString());
			throw e;
		}
		try{
			String str = "";
			String newstr = "";
			String output = "";
			int i = 0;
			int code = arrl.get(i);
			str = al.get(code);
			output = output + str;
			System.out.println(str);
			//Writing into txt file
			FileWriter myWriter = new FileWriter("input1_decoded.txt");
			i++;
			while (i != arrl.size()) {//Checking the file is not empty
				code = arrl.get(i);
				if (code > al.size() - 1) {
					newstr = str + String.valueOf(str.charAt(0));
				} else {
					newstr = al.get(code);
				}
				System.out.println(newstr);
				if (al.size() < maxSize) {
					al.add(str + String.valueOf(newstr.charAt(0)));
				}
				str = newstr;
				output = output + newstr;
				
				i++;
			}
			
			
			myWriter.write(output);
			myWriter.close();
			}
			catch(Exception e){
				System.out.println("Cannot write into file");
			}


	}

}