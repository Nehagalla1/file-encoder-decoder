//Sai Varsha Devineni

import java.util.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.io.*;

public class Encoder {

	public static void main(String[] args) throws Exception {
        //Getting bit length
		double maxSize = Math.pow(2, Integer.parseInt(args[1]));
		ArrayList<String> al = new ArrayList<String>();
		ArrayList<Integer> al1 = new ArrayList<Integer>();
		for (int i = 0; i <= 255; i++) {
			al.add(String.valueOf((char) i));

		}
		String str = "";
		String str1 = "";

		try {
            //Open the file and reads the file
			File myObj = new File(args[0]);
			try (Scanner myReader = new Scanner(myObj)) {
                while (myReader.hasNextLine()) {
                	String data = myReader.nextLine();
                	if (data.isEmpty()) {
                		throw new Exception("Data should not be empty");
                		
                	}
                	int i = 0;
                    //Ensuring that it is not empty file
                	while (i != data.length()) {
                		
                		String symbol = String.valueOf(data.charAt(i));

                		str1 = str + symbol;
                		if (al.contains(str1)) {
                			str = str + symbol;
                		} else {
                			
                			if (al.size() < maxSize) {
                				al.add(str + symbol);
                				str = symbol;
                			}

                		}
                		System.out.println(al.indexOf(str) + " " + str);
                		i++;
                		if (!al1.contains(al.indexOf(str))) {
                			al1.add(al.indexOf(str));
                		}
                	}
                }
                
                //Writes into lzw file
                FileOutputStream fos = new FileOutputStream(new File("input1.lzw"));
                OutputStreamWriter os = new OutputStreamWriter(fos, "utf-16be"); //Using UTF-16BE format and converting into binary format
                for (int j = 0; j < al1.size(); j++) {
                	                	
                	os.write(al1.get(j));
                	
                }
                
                os.close();
                fos.close();
            }
		} catch (FileNotFoundException e) {
			System.out.println("Given file is not found");

		}
	}

}
