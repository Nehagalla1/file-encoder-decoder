//Sai Varsha Devineni

LZW Compression

Project Description:-
LZW is used to compress data without any loss.

The encoding algorithm takes input as '.txt' file, reads the sequence of characters
and convert them in ASCII code. If the character is already present it appends with 
next character and forms new string for which new ASCII code is assigned.
Finally the ASCII codes are converted into 16 bit binary format and saved as '.lzw' file.

The decoding algorithm takes '.lzw' file as input and which reads the binary format
and converts them into decimal format and gets their respective string.

This code works for text files only but may fail for other files.

The programming language used here 'Java' and  compiler version is 17.0.2

Encoder:
It is compiled as- javac Encoder.java 
for executing command is - java Encoder.java input1.txt 12
 • output is written into .lzw file

Decoder:
It is compiled as- javac Decoder.java 
for executing command is - java Decoder.java input1.lzw 12
 • output is written in .txt file